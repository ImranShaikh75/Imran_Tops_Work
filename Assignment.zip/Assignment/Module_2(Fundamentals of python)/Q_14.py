'''What are negative indexes and why are they used?'''
'''Negative Indexing is used to in Python to begin slicing from the end of the string i.e. the last. '''

my_list = ['a','b','c','d','e','f','g']
print(my_list[-1])
print(my_list[-2])
print(my_list[-3])