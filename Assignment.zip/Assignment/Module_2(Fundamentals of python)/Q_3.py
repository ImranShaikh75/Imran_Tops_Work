"//Write a Python program to get the Fibonacci series of given range.?"


n=int(input("Enter The Number : "))

num1, num2 = 0, 1
c =0

if n <= 0:
    print("Please enter a positive integer")
elif n == 1:
    print("Fibonacci sequence  upto ", n,":")
    print(num1)
else:
    print("Fibboacci sequence")
    while c < n:
        print(num1)
        d=num1+num2
        num1=num2
        num2=d
        c+=1