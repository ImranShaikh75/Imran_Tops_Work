'''Write a Python program to calculate the length of a string'''

a=input("Enter String : ")
print(len(a))