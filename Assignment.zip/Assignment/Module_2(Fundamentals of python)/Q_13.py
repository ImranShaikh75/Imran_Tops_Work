'''Write a Python program to count the number of characters (character
frequency) in a string'''

a=input("Enter The String : " )

s={}
for i in a:
    if i in s:
        s[i]=s[i]+1
    else:
        s[i]=1
    print(s)
