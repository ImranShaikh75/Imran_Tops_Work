"""Write a Python program to sum of three given integers. However, if
two values are equal sum will be zero. """
a= int(input("Enter the a value : "))
b= int(input("Enter the b value : "))
c= int(input("Enter the c value : "))

sum=a+b+c
if a==b or b==c or c==a:
    sum=0
else:
    a+b+c
print(sum)
