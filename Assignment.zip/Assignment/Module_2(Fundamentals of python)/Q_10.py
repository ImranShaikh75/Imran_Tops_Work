'''Write a Python program that will return true if the two given integer
values are equal or their sum or difference is 5'''
a=int(input("Enter The 1 Num : "))
b=int(input("Enter The 2 Num : "))

sum=a+b
diff=a-b

if a==b or sum==5 or diff==5:
    print("True")
else:
    print("False")

print(sum)
print(diff)