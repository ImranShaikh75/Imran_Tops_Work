"/ Write a Python program to test whether a passed letter is a vowel or not.?"

l= input("Enter the Value :")

if l=='a':
    print("latter is vowel")
elif l=='e':
    print("latter is vowel")
elif l=='i':
    print("latter is vowel")
elif l=='o':
    print("latter is vowel")
elif l=='u':
    print("latter is vowel")
elif l=='y':
    print("latter is vowel")
else:
    print("latter is consonant")