'''Write a Python function that takes a list of words and returns the length
of the longest one'''
def longest_word_length(words):
    longest_length = 0
    for word in words:
        if len(word) > longest_length:
            longest_length = len(word)
    return longest_length
word_list = ['apple', 'banana', 'orange', 'watermelon', 'strawberry']
longest_length = longest_word_length(word_list)
print("The length of the longest word is:", longest_length)
 