
"Write a Python program to get the Factorial number of given number.?"    
num=int(input("Enter The Number "))


factorial=1
if num<0:
    print("nagative")
elif num ==0:
    print("The factorial 0 is 1")
else:
    for i in range(1,num+1):
        factorial *= i
        print("The factorial of",num,"is",factorial) 








