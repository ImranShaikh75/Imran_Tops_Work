'''
Write python program that swap two number with temp variable and without temp variable?


'''
# with temp 
a=5
b=6
temp=a
a=b
b=temp
print(a)
print(b)

# without temp 

x=8
y=9

x,y=y,x
print(x)
print(y)