'''Write a Python program to find whether a given number is even or odd, print out an appropriate message to the user.'''
num=int(input("Enter the Number = "))

if num%2==0:
    print("The Number is even")
else:
    print("The Number is odd")

