'''
What is the purpose continue statement in python?
The continue keyword is used to end the current iteration in a
 for loop (or a while loop), and continues to the next iteration.
'''