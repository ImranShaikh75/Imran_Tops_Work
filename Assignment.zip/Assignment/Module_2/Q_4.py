'''
How memory is managed in Python?
Memory management in Python involves a private heap containing all Python objects and data structures. 
The management of this private heap is ensured internally by the Python memory manager
'''