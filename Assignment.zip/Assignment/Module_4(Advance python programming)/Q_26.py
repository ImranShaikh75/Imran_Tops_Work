'''What is Instantiation in terms of OOP terminology?'''
'''
===>In the OOP language python, instantiation describes the processes      
    of creating a new object for a class using a new keyword.'''