'''What is File function in python? What is keywords to create and write
file.'''
'''Python file object provides methods and attributes to access and manipulate files. 
    Using file objects, we can read or write any files. 
    Whenever we open a file to perform any operations on it, Python returns a file object. 
    To create a file object in Python use the built-in functions, such as open() and os. popen()'''

# ===>
#     "x" - Create - will create a file, returns an error if the file exist

#     "w" - Write - will create a file if the specified file does not exist