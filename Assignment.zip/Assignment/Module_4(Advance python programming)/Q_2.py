'''Write a Python program to read an entire text file. '''
f=open("read.txt",'r')
print(f.read())