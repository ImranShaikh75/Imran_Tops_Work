'''Write a Python program to read first n lines of a file. '''
f=open("read.txt","r")

line=f.read().splitlines()

print(line)