"""
Write a Python program to read a file line by line store it into a variable. 
"""

f = open("2.read.txt")

str = f.read()

print(str)