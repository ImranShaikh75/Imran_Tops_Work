'''Explain Exception handling? What is an Error in Python? 

~Exception handling:-

===>Exception Handling in python is one of the effective means to handle the runtime errors 
    so that the regular flow of the application can be preserved. 
   
    python Exception Handling is a mechanism to handle runtime errors such as ClassNotFoundException, IOException, SQLException, RemoteException, etc.

~What is an Error in Python :--

===>Error is an illegal operation performed by the user which results in abnormal working of the program. 
    Programming errors often remain undetected until the program is compiled or executed. 
    Some of the errors inhibit the program from getting compiled or executed.'''