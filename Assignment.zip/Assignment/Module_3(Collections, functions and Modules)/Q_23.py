'''Write a Python program to find the length of a tuple.'''
tuple=("Hello World")

print(len(tuple))