'''Write a Python program to reverse a tuple'''
tuplex=(1,2,3,4,5)
x=reversed(tuplex)
print(tuple(x))