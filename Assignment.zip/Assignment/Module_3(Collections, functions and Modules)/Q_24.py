'''Write a Python program to convert a list to a tuple.'''
list=[1,2,3,4,5,6]
print(tuple(list))