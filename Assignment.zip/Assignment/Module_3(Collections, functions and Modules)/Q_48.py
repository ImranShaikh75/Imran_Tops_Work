'''Write a Python function to calculate the factorial of a number (a
nonnegative integer) '''
def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)
n = int(input("Input a number for factorial : "))
print(factorial(n))