'''Write a Python program to remove duplicates from a list.'''
list1=[1,2,3,4,1,2,3,]

newlist=(set(list1))
print(newlist)