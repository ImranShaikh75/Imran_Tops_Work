'''Write a Python program to convert a tuple to a string.'''
tuple=1,2,3,4,5

print(str(tuple))

