'''Write a Python program to get unique values from a list '''


list=[1,2,3,3,4,5,5,6,6,7,8,9,8,7,6,5,4,4,3]
print(list)
set=set(list)
print(set)