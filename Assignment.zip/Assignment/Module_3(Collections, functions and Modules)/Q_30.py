'''Write a Python program to convert a list of tuples into a dictionary.'''
my_list=[(1,'a'),(2,'b'),(3,'c')]

my_dict={key:value for key, value in my_list}
print(my_dict)