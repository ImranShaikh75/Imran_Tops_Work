'''Write a Python program to find the second smallest number in a list'''

num_list = [10, 5, 7, 12, 8, 3, 15]

num_list.sort()

second_smallest = num_list[1]

print("The second smallest number in the list is:", second_smallest)
