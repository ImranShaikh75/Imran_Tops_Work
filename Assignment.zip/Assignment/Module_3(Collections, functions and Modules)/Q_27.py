'''Write a Python program to find the repeated items of a tuple.'''
t=(1,2,2,4,3,5,6,7,9,3,8)
print(t)
count=t.count(4)
print(count)