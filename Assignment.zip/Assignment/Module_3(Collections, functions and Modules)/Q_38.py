'''Write a Python program to check multiple keys exists in a dictionary'''
student = {
  'name': 'imran',
  'class': 'iv',
  'roll_id': '2'
}
print(student.keys() >= {'class', 'name'})
print(student.keys() >= {'name', 'imran'})
print(student.keys() >= {'roll_id', 'name'})