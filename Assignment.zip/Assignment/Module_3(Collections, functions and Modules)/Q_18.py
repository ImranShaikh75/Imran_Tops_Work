'''What is tuple?''' 
'''a tuple is an immutable sequence of values. Like a list, a tuple can 
contain elements of any data type, including other lists, tuples, and dictionaries. 
However, unlike lists, tuples are immutable, meaning their values cannot be modified once they are created.'''


'''Difference between list and tuple.'''

'''Mutability: As mentioned, lists are mutable, while tuples are immutable. This means that you can modify the values in a list after it has been created, but you cannot modify the values in a tuple.'''

'''Syntax: In Python, a list is defined using square brackets ([]), while a tuple is defined using parentheses (()).'''

'''Performance: Because tuples are immutable, they can be faster to access and iterate through than lists. This is because Python does not need to create a new memory allocation every time an element in a tuple is accessed or modified.'''

'''Use cases: Lists are often used for storing and manipulating data that can change over time, such as the results of a database query or the contents of a user's shopping cart on an e-commerce site. Tuples, on the other hand, are often used for storing and passing around data that should not change, such as the latitude and longitude of a location, or the name and address of a customer.'''