'''Write a Python program to check a list is empty or not'''

list=[6,5,4]
if not list:
    print("Empty")
else:
    print("not empty")