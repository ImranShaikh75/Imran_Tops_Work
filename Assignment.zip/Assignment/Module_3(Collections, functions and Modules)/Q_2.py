'''How will you remove last object from a list?'''
my_list=[1,2,3,4,5]
new_my_list=my_list[:-1]
print(new_my_list)