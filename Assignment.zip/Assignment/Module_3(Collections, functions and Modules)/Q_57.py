'''How will you randomizes the items of a list in place? '''
import random

my_list = [1, 2, 3, 4, 5]
random.shuffle(my_list)
print(my_list)

'''Note that the shuffle() function only works with mutable sequences like lists, not with immutable sequences like tuples. If you need to shuffle the items of a tuple, you can first convert it to a list, shuffle the list, and then convert it back to a tuple'''
