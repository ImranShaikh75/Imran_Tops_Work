'''Write a Python script to check if a given key already exists in a
dictionary. 
'''

my_dict = {"name": "John", "age": 25, "gender": "male"}

search_key = "name"

if search_key in my_dict:
    print(f"{search_key} exists in the dictionary")
else:
    print(f"{search_key} does not exist in the dictionary")
