'''Write a Python program to split a list into different variables. '''
list1=[1,2,3,4,5]

a,b,c,d,e =list1
print(a)
print(b)
print(c)
print(d)
print(e)