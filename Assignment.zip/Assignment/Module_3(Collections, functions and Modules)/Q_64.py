'''Write a Python program to find the maximum and minimum numbers
from the specified decimal numbers. '''
numbers = [3.5, 2.1, 7.8, 1.9, 5.4] 

maximum = max(numbers)
minimum = min(numbers)

print("The maximum number is:", maximum)
print("The minimum number is:", minimum)

