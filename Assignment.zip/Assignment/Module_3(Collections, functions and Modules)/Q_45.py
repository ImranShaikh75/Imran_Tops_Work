'''Write a Python program to find the highest 3 values in a dictionary'''
my_dict = {'a': 100, 'b': 200, 'c': 300, 'd': 400, 'e': 500}

# Get a list of all the values in the dictionary
values = list(my_dict.values())

# Sort the list in descending order
values.sort(reverse=True)

# Print the top 3 values
print(values[:3])
