'''Write a Python program to convert degree to radian 
'''
pi=22/7
digree=22

radian=digree *(pi/180)
print(radian)