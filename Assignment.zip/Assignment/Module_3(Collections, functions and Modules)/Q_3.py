'''Differentiate between append () and extend () methods?'''
'''
append() : method adds a single element to the end of the list. 
It takes a single argument and modifies the original list by adding 
the argument as a new element at the end of the list.
'''

my_list=[1,2,3,4]
my_list.append(5)
print(my_list)

'''
extend(): method takes an iterable as an argument, such as another list or a tuple,
and appends each of its elements to the end of the original list. 
It modifies the original list by adding all the elements of the iterable to the end of the list.
'''
my_list=[1,2,3,4,5]
new_my_list=[6,7,8]
my_list.extend(new_my_list)
print(my_list)

