'''How can you pick a random item from a list or tuple? '''
import random

my_list = ['apple', 'banana', 'orange', 'grape']
random_item = random.choice(my_list)
print(random_item)


# in tuple
import random

my_tuple = ('apple', 'banana', 'orange', 'grape')
random_item = random.choice(my_tuple)
print(random_item)
