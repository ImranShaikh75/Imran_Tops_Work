''' Write a Python program to calculate the area of a trapezoid'''
# specify the height and the two bases of the trapezoid
height = 5
base1 = 10
base2 = 15

# calculate the area of the trapezoid using the formula
area = ((base1 + base2) * height) / 2

# print the result
print("The area of the trapezoid is:", area)
