'''Write a Python program to select an item randomly from a list. '''
import random
list=['a','b','c','d','e','f','g']
print(random.choice(list))