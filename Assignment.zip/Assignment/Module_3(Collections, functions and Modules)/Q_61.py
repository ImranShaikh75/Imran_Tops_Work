'''Write a Python program to calculate the area of a parallelogram'''

base = 8
height = 12

area = base * height

print("The area of the parallelogram is:", area)
