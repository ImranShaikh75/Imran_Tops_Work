'''How Do You Traverse Through A Dictionary Object In Python?'''
'''

There are multiple ways to iterate over a dictionary in Python.

-Access key using the build .keys() 
-Access key without using a key() 
-Iterate through all values using .values()
-Iterate through all key, and value pairs using items()
-Access both key and value without using items()
-Print items in Key-Value in pair '''

statesAndCapitals = {
    'Gujarat': 'Gandhinagar',
    'Maharashtra': 'Mumbai',
    'Rajasthan': 'Jaipur',
    'Bihar': 'Patna'
}
 
keys = statesAndCapitals.keys()
print(keys)
# ---------------------------------------
print('List Of given states:\n')

for state in statesAndCapitals:
    print(state)
# --------------------------------------->
print('List Of given capitals:\n')
for capital in statesAndCapitals.values():
    print(capital)

# ----------------------------------------->
print('List Of given states and their capitals:\n')
 
for state, capital in statesAndCapitals.items():
    print(state, ":", capital)
# ------------------------------------------->
