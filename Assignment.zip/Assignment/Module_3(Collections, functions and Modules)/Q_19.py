'''Write a Python program to create a tuple with different data types'''
tuple=('tuple',False,4,5,6)
print(tuple)