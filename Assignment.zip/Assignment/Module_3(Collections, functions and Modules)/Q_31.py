'''How will you create a dictionary using tuples in python?'''

tuple=((1,'a'),(2,'b'),(3,'c'))
dict={key:value for key, value in tuple}
print(dict)