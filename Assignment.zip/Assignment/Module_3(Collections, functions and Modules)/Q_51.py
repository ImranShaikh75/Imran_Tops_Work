'''Write a Python function that checks whether a passed string is
palindrome or not'''
def isPalindrome(str):
    return str == str[::-1]
 
str = "malayalam"
ans = isPalindrome(str)
 
if ans:
    print("pelindrom !")
else:
    print("not pelindrom !")