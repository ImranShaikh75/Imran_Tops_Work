'''How will you set the starting value in generating random numbers? '''
import random

random.seed(42)  # Set the starting value to 42
random_number = random.randint(1, 10)
print(random_number)
