'''Write a Python function that takes two lists and returns true if they have
at least one common member'''

def common_member(l1,l2):
    for i in l1:
        if i in l2:
            return True
        return False
    
l1 = [1, 2, 3, 4]
l2 = [5, 6, 7, 8]
l3 = [4, 5, 6, 7]

print(common_member(l1, l2))
print(common_member(l1, l3))
