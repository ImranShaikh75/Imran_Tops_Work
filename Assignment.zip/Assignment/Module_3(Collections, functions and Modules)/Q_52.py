'''How Many Basic Types Of Functions Are Available In Python? '''
# Built-in functions: These are the functions that are pre-defined in Python and are available to use directly. Examples include print(), len(), and type().'''

# User-defined functions: These are the functions that are defined by the user according to their requirements using the def keyword.

# Anonymous functions or lambda functions: These are functions that are defined without a name and can be created using the lambda keyword.

# Recursive functions: These are functions that call themselves during their execution.

# Higher-order functions: These are functions that accept another function as an argument or return another function as a result.

# Methods: These are functions that are associated with an object and can be called on that object using the dot notation. Examples include append() for lists and upper() for strings.