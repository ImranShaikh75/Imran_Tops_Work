'''Write a Python program to check whether an element exists within a
tuple'''
tuple=('T','o','p','s','t','e','c','h')
print("o" in tuple)
print(5 in tuple)