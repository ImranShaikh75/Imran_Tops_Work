'''Write a Python function to get the largest number, smallest num and sum
of all from a list'''

def list_stats(lst):
    # check if the list is empty
    if len(lst) == 0:
        return None, None, 0  # return None for max and min, and 0 for sum
    else:
        max_num = max(lst)
        min_num = min(lst)
        sum_nums = sum(lst)
        return max_num, min_num, sum_nums



my_list = [3, 7, 1, 9, 5]
max_num, min_num, sum_nums = list_stats(my_list)
print("Max number:", max_num)  # Output: Max number: 9
print("Min number:", min_num)  # Output: Min number: 1
print("Sum of all numbers:", sum_nums)  # Output: Sum of all numbers: 25
