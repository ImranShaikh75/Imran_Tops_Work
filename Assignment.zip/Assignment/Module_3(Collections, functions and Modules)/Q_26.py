'''Write a Python program to replace last value of tuples in a list.'''
list=[(10,20,30)]
print([t[:-1]+(100,)for t in list])