'''Write a Python program to convert a list of characters into a string.'''
# Define a list of characters
char_list = ['H', 'e', 'l', 'l', 'o', ',', ' ', 'w', 'o', 'r', 'l', 'd', '!']

# Convert the list of characters to a string
str = ''.join(char_list)

# Print the resulting string
print(str)
