'''Write a Python program to create a tuple with numbers.'''
tuple=(1,2,3,4,5)
print(tuple)