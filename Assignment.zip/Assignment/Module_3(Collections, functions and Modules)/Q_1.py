'''What is List?'''
# Lists are used to store multiple items in a single variable.
'''How will you reverse a list? '''

my_list=[1,2,3,4,5,6]
my_list.reverse()
print(my_list)