'''Write a Python program to read a random line from a file. '''
import random

a=open("C:\\Users\\Lenovo\\Desktop\\Assignment\\Module_3\\Read.txt",'r')
line=a.read().splitlines()

print(line)
print(line[0])

print(random.choice(line))