'''Write a Python program to check whether a list contains a sub list'''
list1 = [1,2,3,4,5]
list2 = [2,3]


n = 0
for i in range(len(list1)):
    if list1[i] == list2[0]:
        n = 1
        while (n<len(list2)) and (list1[i + n]) == list2[n]:
            n += 1

        if n == len(list2):
            print("subset of main list")