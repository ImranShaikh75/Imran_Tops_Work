'''How can you pick a random item from a range? '''
import random

my_range = range(1, 10)
random_item = random.choice(my_range)
print(random_item)

