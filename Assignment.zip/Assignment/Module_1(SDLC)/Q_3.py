'''
What is programing?
“Programming is how you get computers to solve problems.”
'''