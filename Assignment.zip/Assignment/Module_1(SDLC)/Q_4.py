'''
4)What is Python?
Ans= Python is an interpreted, object-oriented, high-level programming language with dynamic type programing language

'''