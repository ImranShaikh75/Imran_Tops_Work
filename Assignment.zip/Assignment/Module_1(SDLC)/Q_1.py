'''
what is software?
Ans->What is the definition of software?
Software is a set of instructions, data or programs used to operate computers and execute specific tasks. 


'''